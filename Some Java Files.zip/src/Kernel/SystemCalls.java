package Kernel;

import General.Cpu;
import Processes.ProcessControlBlock;
import Processes.ProcessState;

import java.io.BufferedReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * Created by northwind on 11/14/2017.
 */
public class SystemCalls {

    static final String textFileDirectory = "C:/Temp/OSTextFiles/";

    private static ArrayList<ProcessControlBlock> pcbChain = new ArrayList<>();
    private static ReadyQueue readyQueue = new ReadyQueue();

    private static Cpu cpu = new Cpu(1);

    public static void addProcess(ProcessControlBlock pcb) {
        pcbChain.add(pcb);
    }

    public static boolean loadProgramFromFile(String filename) {
        try(BufferedReader reader = Files.newBufferedReader(Paths.get(textFileDirectory + filename), StandardCharsets.UTF_8)) {
            ArrayList<String> codeLines = new ArrayList<>();
            String line;
            while((line = reader.readLine()) != null) {
                codeLines.add(line);
            }
            ProcessControlBlock pcb = new ProcessControlBlock(Arrays.copyOf(codeLines.toArray(), codeLines.size(), String[].class));
            addProcess(pcb);
            readyQueue.addProcessToQueue(pcb);

            System.out.println("In load system call");
            for(String theLine: codeLines) {
                System.out.println(theLine);
            }
            System.out.println("Exiting load system call");

        } catch (Exception e) {
            System.out.println(e.toString());
            return false;
        }
        return true;
    }




    public static ProcessControlBlock getNextInReadyQueue() {
        return readyQueue.getNextInQueueToRun();
    }

    public static void returnBackToReadyQueue(ProcessControlBlock pcb) {
        readyQueue.returnProcessToReadyQueue(pcb);
    }





    public static void execute(int cycles) {
        cpu.addCycles(cycles);
    }

    public static ArrayList<ProcessControlBlock> getPcbChain() {
        return pcbChain;
    }

    public static void printThreadInformation() {
        for(Thread t : cpu.getThreads()) {
            System.out.println(t.getId() + ": " + t.getState());
        }
    }

}




class ReadyQueue {

    ArrayList<ProcessControlBlock> primaryQueue;
    //ArrayList<ProcessControlBlock> waitingQueue;
    private int readyCount;

    public synchronized void notifyReadyAdd() {
        readyCount++;
        notifyAll();
    }

    public synchronized void notifyReadyRemove() {
        readyCount--;
    }

    //private static Semaphore readyQueueSemaphore;

    public ReadyQueue() {
        primaryQueue = new ArrayList<>();
        readyCount = 0;
    }


    public synchronized void addProcessToQueue(ProcessControlBlock pcb) {
        primaryQueue.add(pcb);
        notifyReadyAdd();
    }

    public synchronized void returnProcessToReadyQueue(ProcessControlBlock pcb) {
        if(pcb.getState() == ProcessState.EXIT) {
            primaryQueue.remove(pcb);
        } else if (pcb.getState() == ProcessState.RUN) {
            primaryQueue.get(primaryQueue.indexOf(pcb)).setState(ProcessState.READY);
            notifyReadyAdd();
        }
    }

    public synchronized void returnProcessToWaitingQueue() {}

    // some outside method called "execute(Processes pcb, int cycles)"
    // cpu.available?
    public synchronized ProcessControlBlock getNextInQueueToRun() {
        try {
            while(readyCount == 0) { wait(); }
        } catch (Exception e) {}
        while(primaryQueue.size() > 0) {
            ProcessControlBlock pcb;
            pcb = primaryQueue.remove(0);
            primaryQueue.add(pcb);
            if(pcb.getState() == ProcessState.READY) {
                pcb.setState(ProcessState.RUN);
                notifyReadyRemove();
                pcb.cyclesAllocated += 100;
                return pcb;
            }
        }
        return null;
    }
}
