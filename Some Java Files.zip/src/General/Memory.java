package General;

/**
 * Created by northwind on 11/14/2017.
 */
public class Memory {
}
