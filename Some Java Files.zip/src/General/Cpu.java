package General;

import java.util.concurrent.Semaphore;

import Kernel.SystemCalls;
import Processes.ProcessControlBlock;
import Processes.ProcessState;

import static Processes.ProcessState.RUN;

/**
 * Created by northwind on 11/14/2017.
 */
public class Cpu {

    Semaphore cyclesSemaphore;
    public Thread[] threads;

    public Cpu(int numThreads) {
        threads = new Thread[numThreads];
        cyclesSemaphore = new Semaphore(0);
        for(int i = 0; i < numThreads; i++) {
            threads[i] = new Thread(new ExecutionThread(), "thread1");
            threads[i].start();
        }
    }

    public void addCycles(int numCycles) {
        cyclesSemaphore.release(numCycles);
    }

    public void setCyclesZero() {
        try { cyclesSemaphore.drainPermits();
        } catch (Exception e) {}
    }

    public Thread[] getThreads() {
        return threads;
    }

    class ExecutionThread implements Runnable {

        public ExecutionThread() {}

        public void run() {

            ProcessControlBlock pcb = null;
            while(true) {
                pcb = SystemCalls.getNextInReadyQueue();

                while(pcb.getState() == RUN && pcb.cyclesAllocated > 0) {
                    if(execute(pcb.getCodeLine(), pcb) == false) {
                        pcb.setState(ProcessState.EXIT);
                    }
                    pcb.cyclesAllocated--;
                }
                SystemCalls.returnBackToReadyQueue(pcb);
            }
        }

        // make cycles decrement in here
        private boolean execute(String line, ProcessControlBlock pcb) {
            if(line != null) {


                System.out.println(line);
                try { cyclesSemaphore.acquire();
                } catch (Exception e) {}
                pcb.cyclesAllocated--;



                return true;
            } else { return false; }
        }

    }
}