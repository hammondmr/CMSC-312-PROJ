package General;

import Kernel.SystemCalls;
import Processes.ProcessControlBlock;
import Processes.ProcessState;

import java.util.Scanner;

public class Main {

    static Scanner in;
    static final String precurser = "> ";


    public static void main(String[] args) {

        in = new Scanner(System.in);
        shellLoop();

    }

    static void shellLoop() {
        String inputLine = "";
        while(true) {
            System.out.print(precurser);
            inputLine = in.nextLine();
            processInput(inputLine);
        }
    }

    static void processInput(String input) {

        String[] arguments = input.split(" ");
        if(arguments.length == 0) {
            System.out.println("");
            return;
        }
        /////////////////////////////////////
        if(arguments[0].equals("EXIT")) {
            System.exit(0);
        }
        /////////////////////////////////////
        if(arguments[0].equals("LOAD")) {
            if(arguments.length > 1) {
                if(SystemCalls.loadProgramFromFile(arguments[1]) == false) {
                    System.out.println("File load error");
                }
            } else {
                System.out.println("No file entered");
            }
            return;
        }
        /////////////////////////////////////
        if(arguments[0].equals("EXEC")) {
            int cycles = 0;
            if(arguments.length > 1) {
                try {
                    cycles = Integer.parseInt(arguments[1]);
                } catch(NumberFormatException e) {
                    System.out.println("invalid number of cycles entered");
                }
            } else {
                cycles = 100;
            }
            System.out.println("EXEC shell cycles: " + cycles);
            SystemCalls.execute(cycles);
            return;
        }
        ////////////////////////////////////
        if(arguments[0].equals("PROC")) {
            for(ProcessControlBlock pcb : SystemCalls.getPcbChain()) {
                System.out.println(pcb.getPid());
            }
            SystemCalls.printThreadInformation();
            System.out.println("done");
        }
        else {
            System.out.println("Invalid command");
            return;
        }

    }
}
