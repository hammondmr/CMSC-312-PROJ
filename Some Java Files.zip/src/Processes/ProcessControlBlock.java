package Processes;

import java.util.ArrayList;

public class ProcessControlBlock {

    int pid;
    int programCounter;
    String[] textSection;
    ProcessState state;
    ArrayList<Integer> pageTable;
    public int cyclesAllocated;

    static int uniqueIndentifier = 0;
    static final ProcessState initialState = ProcessState.READY;

    public ProcessControlBlock(String[] text) {

        textSection = text;
        programCounter = 0;
        pid = uniqueIndentifier++;
        state = initialState;
        pageTable = new ArrayList<>();
        cyclesAllocated = 0;

    }

    public String getCodeLine() {
        if(programCounter >= textSection.length) return null;
        String line = textSection[programCounter];
        programCounter++;
        return line;
    }

    public boolean allocatePages() {
        return true;
    }

    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof ProcessControlBlock)) {
            return false;
        }
        ProcessControlBlock pcb2 = (ProcessControlBlock) obj;
        if (this.pid == pcb2.pid) {
            return true;
        }
        return false;
    }

    public void setState(ProcessState s) {
        state = s;
    }

    public ProcessState getState() {
        return state;
    }

    public int getPid() {
        return pid;
    }
}
