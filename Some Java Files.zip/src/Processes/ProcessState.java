package Processes;

/**
 * Created by northwind on 11/14/2017.
 */
public enum ProcessState {
    NEW, READY, RUN, WAIT, EXIT
}